<?php $__env->startSection('content'); ?>
   <div class="section__content section__content--p30">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="mt-5">
                        <div class="card card-primary">
                            <div class="card-header">
                              <h3 class="card-title">
                                <?php if($game): ?>
                                  Edit
                                <?php else: ?>
                                  New
                                <?php endif; ?> Game
                              </h3>
                            </div>
                           
                            <form method="POST" id="form_new_game">
                            <?php echo csrf_field(); ?>
                              <div class="card-body">
                                <div class="form-group">
                                  <label for="">Game Title</label>
                                  <input type="text" name="title" class="form-control required" value="<?php if($game): ?> <?php echo e($game->title); ?> <?php endif; ?>" placeholder="Enter title">
                                </div>
                                <div class="form-group">
                                    <label for="">Game Description</label>
                                    <textarea type="text" name="description" class="form-control required"  placeholder="Enter description"><?php if($game): ?> <?php echo e($game->description); ?> <?php endif; ?></textarea>
                                </div>
                                <div class="form-group">
                                  <label for="">Main Category</label>
                                  <select name="main_category" class="form-control main_category required">
                                    <option value="">------Select Main Category-----</option>
                                    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <option value="<?php echo e($item->id); ?>" <?php if($game): ?> <?php if($game->cat_main == $item->id): ?> selected <?php endif; ?> <?php endif; ?> ><?php echo e($item->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </select>
                                </div>                                
                                <div class="form-group">
                                  <label for="">Price</label>
                                  <input type="text" name="price" class="form-control required" value="<?php if($game): ?> <?php echo e($game->price); ?> <?php endif; ?>" placeholder="">
                                </div>
                                <div class="form-group">
                                    <label for="">Developer Name</label>
                                    <input type="text" name="dev_name" class="form-control" value="<?php if($game): ?> <?php echo e($game->dev_name); ?> <?php endif; ?>" placeholder="">
                                </div>
                                <div class="form-group">
                                    <label for="">Developer Email</label>
                                    <input type="email" name="dev_email" class="form-control" value="<?php if($game): ?> <?php echo e($game->dev_email); ?> <?php endif; ?>" placeholder="">
                                </div>

                                <div class="form-group">
                                  <label for="">System Requirements</label>
                                  <div class="border-radius-area">
                                    <div class="row mb-3">
                                      <div class="col-md-4">
                                        <label for="">Available OS</label>
                                      </div>
                                      <div class="col-md-8">
                                        <input type="text" name="available_os" value="<?php if($game): ?> <?php echo e($game->available_os); ?> <?php endif; ?>" class="form-control">
                                      </div>
                                    </div>
                                    <div class="row mb-3">
                                      <div class="col-md-4">
                                        <label for="">Available OS Bit</label>
                                      </div>
                                      <div class="col-md-8">
                                        <input type="text" name="available_os_bit" class="form-control" value="<?php if($game): ?> <?php echo e($game->available_os_bit); ?> <?php endif; ?>">
                                      </div>
                                    </div>
                                    <div class="row mb-3">
                                      <div class="col-md-4">
                                        <label for="">Processor</label>
                                      </div>
                                      <div class="col-md-8">
                                        <input type="text" name="processor" class="form-control" value="<?php if($game): ?> <?php echo e($game->processor); ?> <?php endif; ?>">
                                      </div>
                                    </div>
                                    <div class="row mb-3">
                                      <div class="col-md-4">
                                        <label for="">Memory</label>
                                      </div>
                                      <div class="col-md-8">
                                        <input type="text" name="memory" class="form-control" value="<?php if($game): ?> <?php echo e($game->memory); ?> <?php endif; ?>">
                                      </div>
                                    </div>
                                    <div class="row mb-3">
                                      <div class="col-md-4">
                                        <label for="">DirectX Version</label>
                                      </div>
                                      <div class="col-md-8">
                                        <input type="text" name="direct" class="form-control" value="<?php if($game): ?> <?php echo e($game->direct); ?> <?php endif; ?>">
                                      </div>
                                    </div>
                                    <div class="row mb-3">
                                      <div class="col-md-4">
                                        <label for="">Disk Space</label>
                                      </div>
                                      <div class="col-md-8">
                                        <input type="text" name="disk_space" class="form-control" value="<?php if($game): ?> <?php echo e($game->disk_space); ?> <?php endif; ?>">
                                      </div>
                                    </div>
                                    <div class="row mb-3">
                                      <div class="col-md-4">
                                        <label for="">Graphics</label>
                                      </div>
                                      <div class="col-md-8">
                                        <input type="text" name="graphics" class="form-control" value="<?php if($game): ?> <?php echo e($game->graphics); ?> <?php endif; ?>">
                                      </div>
                                    </div>
                                    <div class="row mb-3">
                                      <div class="col-md-4">
                                        <label for="">Additional Notes</label>
                                      </div>
                                      <div class="col-md-8">
                                        <input type="text" name="additional" class="form-control" value="<?php if($game): ?> <?php echo e($game->additional); ?> <?php endif; ?>">
                                      </div>
                                    </div>
                                  </div>
                                </div>

                                <div class="form-group">
                                  
                                  
                                  <div class="row">
                                    <div class="col-md-4">
                                      <label for="">Language</label>
                                    </div>
                                    <div class="col-md-8">
                                      <select multiple="multiple" name="" placeholder="Select Language" class="SlectBox required form-control">
                                        <option value="English(United Status)">English</option>
                                        <option value="Chiness(Simplified)">Chinese(Simplified)</option>
                                        <option value="Chiness(Traditional)">Chinese(Traditional)</option>
                                        <option value="French(France)">French(France)</option>
                                        <option value="German">German</option>
                                        <option value="Italian">Italian</option>
                                        <option value="Japanese">Japanese</option>
                                        <option value="Korean(South Korea)">Korean(South Korea)</option>
                                        <option value="Russian">Russian</option>
                                        <option value="Spanish">Spanish</option>
                                      </select>
                                      
                                      
                                    </div>
                                  </div>
                                  <div class="language_area" style="display: none;">
                                        
                                  </div>
                                </div>

                                <div class="form-group">
                                  <label for="">Game Play</label>
                                  <div class="border-radius-area">
                                    <div class="row mb-3">
                                      <div class="col-md-4">
                                        <label for="">Playing time</label>
                                      </div>
                                      <div class="col-md-8">
                                        <input type="text" name="playing_time" class="form-control required" value="<?php if($game): ?> <?php echo e($game->playing_time); ?> <?php endif; ?>">
                                      </div>
                                    </div>
                                    <div class="row mb-3">
                                      <div class="col-md-4">
                                        <label for="">Scoring</label>
                                      </div>
                                      <div class="col-md-8">
                                        <input type="text" name="scoring" class="form-control required" value="<?php if($game): ?> <?php echo e($game->scoring); ?> <?php endif; ?>">
                                      </div>
                                    </div>
                                    <div class="row mb-3">
                                      <div class="col-md-4">
                                        <label for="">Number of players</label>
                                      </div>
                                      <div class="col-md-8">
                                        <input type="text" name="num_players" class="form-control required" value="<?php if($game): ?> <?php echo e($game->num_players); ?> <?php endif; ?>">
                                      </div>
                                    </div>
                                  </div>
                                </div>

                                <div class="form-group">
                                  <label for="">Compatible With</label>
                                  <div class="border-radius-area">
                                    <div class="row mb-3">
                                      
                                      <div class="col-md-12">
                                        <div class="added_compatible_item">
                                          <?php if($game): ?>
                                            <?php
                                                $compatible_with = json_decode($game->compatible_with); 
                                            ?>
                                          <?php else: ?>
                                            <?php
                                                $compatible_with = ''; 
                                            ?>
                                          <?php endif; ?>

                                          <?php $__currentLoopData = $compatible; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $is_check = False;
                                            ?>
                                            <?php if(!empty($compatible_with)): ?>
                                              <?php for($i = 0; $i < count($compatible_with); $i++): ?>
                                                <?php if($item->id == $compatible_with[$i]): ?> 
                                                  <?php
                                                    $is_check = True;
                                                  ?>
                                                <?php endif; ?>
                                              <?php endfor; ?>
                                            <?php endif; ?>
                                            
                                            <div class="form-check d-inline-block mr-3">
                                              <input type="checkbox" class="form-check-input" name="compatible_with[]" value="<?php echo e($item->id); ?>" id="compatible_with_<?php echo e($item->id); ?>" <?php if($is_check): ?> checked <?php endif; ?>>
                                              <label class="form-check-label" for="compatible_with_<?php echo e($item->id); ?>"><?php echo e($item->name); ?></label>
                                            </div>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                          
                                        </div>
                                      </div>
                                    </div>                                    
                                  </div>
                                </div>

                                <div class="form-group">
                                  <label for="exampleInputFile">Main Image</label>
                                  <div class="input-group">
                                    <div class="custom-file">
                                      <input type="file" class="custom-file-input" id="mainImage" accept=".jpg, .jpeg, .png, .svg, .mp4, .avi " multiple>
                                      <label class="custom-file-label" for="mainImage">Choose file</label>
                                    </div>                                   
                                  </div>
                                  
                                </div>
                                <div class="form-group">
                                  <div class="" style="padding:10px;">
                                    <ul class="upload_post_image">
                                      <?php if($game): ?>
                                        <?php
                                            $mainImages = json_decode($game->main_imgs);                        
                                        ?> 
            
                                        <?php for($i = 0; $i < count($mainImages); $i++): ?>
                                            <li class="upload_post_image_item">
                                              <div class="pos_rel game_img_wrap">
                                              <button type="button" class="btn_transparent btn_post_img_delete" data-value="<?php echo e($mainImages[$i]); ?>"><i class="fa fa-times text-color-red"></i></button>
                                              <img class="uploaded_game_image" src="<?php echo e(asset('public/upload/game/'.$mainImages[$i])); ?>" alt="">
                                              </div>
                                              <input name="image_name[]" type="hidden" value="<?php echo e($mainImages[$i]); ?>">
                                            </li>
                                        <?php endfor; ?>
                                      <?php endif; ?>
                                      
                                    </ul>
                                  </div>
                                </div>

                                <div class="form-group">
                                  <label for="exampleInputFile">Sub Image</label>
                                  <div class="input-group">
                                    <div class="custom-file">
                                      <input type="file" class="custom-file-input" id="subImage" accept=".jpg, .jpeg, .png" multiple>
                                      <label class="custom-file-label" for="subImage">Choose file</label>
                                    </div>                                   
                                  </div>
                                  
                                </div>
                                <div class="form-group">
                                  <div class="" style="padding:10px;">
                                    <ul class="upload_post_image_sub">
                                      <?php if($game): ?>
                                        <?php
                                            $subImages = json_decode($game->sub_imgs);                        
                                        ?> 
                                        
                                        <?php for($i = 0; $i < count($subImages); $i++): ?>
                                            <li class="upload_post_image_item_sub">
                                              <div class="pos_rel game_img_wrap">
                                                <button type="button" class="btn_transparent btn_post_img_delete_sub" data-value="<?php echo e($subImages[$i]); ?>"><i class="fa fa-times text-color-red"></i></button>
                                                <img class="uploaded_game_image" src="<?php echo e(asset('public/upload/game/'.$subImages[$i])); ?>" alt="">
                                              </div>
                                              <input name="image_name_sub[]" type="hidden" value="<?php echo e($subImages[$i]); ?>">
                                            </li>
                                        <?php endfor; ?>  
                                      <?php endif; ?>
                                    </ul>
                                  </div>
                                </div>
                               
                                <div class="form-group">
                                  <label for="">Select Game Type</label>
                                  <div class="border-radius-area">
                                    <div class="row mb-3">
                                      <div class="col-md-12">
                                        <div class="form-check d-inline-block mr-3">
                                          <input class="form-check-input" type="radio" value="1" <?php if($game): ?> <?php if($game->status == '1'): ?> checked <?php endif; ?> <?php endif; ?> name="status">
                                          <label class="form-check-label">Publish</label>
                                        </div>
                                        <div class="form-check d-inline-block mr-3">
                                          <input class="form-check-input" type="radio" value="9" <?php if($game): ?> <?php if($game->status == '9'): ?> checked <?php endif; ?> <?php endif; ?> name="status">
                                          <label class="form-check-label">Most Popular</label>
                                        </div>
                                        <div class="form-check d-inline-block mr-3">
                                          <input class="form-check-input" type="radio" value="99" <?php if($game): ?> <?php if($game->status == '99'): ?> checked <?php endif; ?> <?php endif; ?> name="status">
                                          <label class="form-check-label">Coming Soon</label>
                                        </div>
                                        <div class="d-inline-block">
                                          <input type="date" name="expected_date" <?php if($game): ?> value="<?php echo e($game->expected_date); ?>" <?php endif; ?> class="form-control">
                                        </div>
                                      </div>
                                    </div>                                   
                                  </div>
                                </div>
                              </div>
                              <!-- /.card-body -->
              
                              <div class="card-footer">
                                <button type="button" class="btn btn-primary btn_store_game">
                                  
                                  <?php if($game): ?>
                                    Update
                                  <?php else: ?>
                                    Register
                                  <?php endif; ?>
                                </button>
                                <a href="<?php echo e(route('admin.games')); ?>" class="btn btn-cancel">Cancel</a>
                              </div>
                              <input type="hidden" name="game_id" value="<?php if($game): ?> <?php echo e($game->id); ?> <?php endif; ?>">
                            </form>
                        </div>
                    </div>
                </div>    
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Daily-Work\test\gamesite\resources\views/admin/games.blade.php ENDPATH**/ ?>