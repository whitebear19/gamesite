<?php $__env->startSection('content'); ?>

<section class="content mt-2">
    <div class="container-fluid">
    
        <div class="row">
            <table class="table">
                <thead>
                    <tr>
                        <td>No</td>
                        <td>Game Title</td>
                        <td>Price</td>
                        <td>Status</td>
                        <td>Action</td>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $i=1
                    ?>
                    <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($i); ?></td>
                            <td><a href=""><?php echo e($item->title); ?></a></td>
                            <td><?php echo e($item->price); ?></td>
                            <td>
                                
                                <select name="" class="select_game_status" data-id="<?php echo e($item->id); ?>">
                                    <option value="1" <?php if($item->status == '1'): ?> selected <?php endif; ?>>Publish</option>    
                                    <option value="0" <?php if($item->status == '0'): ?> selected <?php endif; ?>>Pending</option>    
                                </select>                        
                            </td>
                            <td>
                                <button data-id="<?php echo e($item->id); ?>" class="btn_transparent col-green btn_edit_game"><i class="far fa-edit" aria-hidden="true"></i></button>
                                <button data-id="<?php echo e($item->id); ?>" class="btn_transparent btn_delete_game col-red"><i class="far fa-trash-alt" aria-hidden="true"></i></button> 
                            </td>
                        </tr>
                        <?php
                            $i=$i+1;
                        ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        
    </div>
    <form action="<?php echo e(route('admin.games')); ?>" class="form_edit_game d-none" method="get">
        <input type="hidden" value="" name="id" class="form_edit_game_id">
    </form>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Daily-Work\test\gamesite\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>