<?php $__env->startSection('content'); ?>

<section class="content mt-2">
    <div class="container-fluid">
    
        <div class="row">
            test
        </div>
        
    </div>   
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.company', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Daily-Work\test\gamesite\resources\views/company/dashboard.blade.php ENDPATH**/ ?>