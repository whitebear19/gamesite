<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Compatible extends Model
{
    protected $guarded = [];
}
