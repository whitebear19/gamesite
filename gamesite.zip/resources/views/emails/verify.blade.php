<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>I-Oasis</title>
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,500,600,700,800,900" rel="stylesheet">

</head>

<body style="background:#f1f1f1;padding-top:20px;padding-bottom:20px;">
    <center>
        <table class="" border="0" cellspacing="0" cellpadding="0" width="600"
            style="width:6.25in;background:#ffffff; border-collapse:collapse;padding:20px 20px 20px 20px;">
            <tbody>
                <tr>
                    <td height="30"></td>
                </tr>   
                <tr>
                    <td>
                        <center>
                            <a href="http://i-oasis.fr" style="display: inline-block;">
                                <img src="http://i-oasis.fr/public/assets/img/logo.png" style="width: 55px;height:65px;" alt="" srcset="">
                            </a>
                        </center>
                    </td>
                </tr>   
                <tr>
                    <td height="10"></td>
                </tr>     
                <tr>
                    <td>
                        <center>
                            <p>
                                <span style="color: black;font-size: 20px;">Welcome to</span>                               
                                <span style="color: rgb(42, 7, 138);font-size: 20px;">I-Oasis.fr</span>                               
                            </p>
                        </center>
                    </td>
                </tr>   
                <tr>
                    <td style="padding: 0px 20px 0px 18px;">
                        <center>
                            <p>
                                <span style="color: black;font-size: 18px;">Please click the button below to verify your email address.</span>                            
                            </p>  
                        </center>         
                    </td>
                </tr>         
                <tr>
                    <td style="padding: 0px 20px 0px 20px;">
                        <center>
                            <a href="http://i-oasis.fr/email/verify/{{ $id }}" style="display: inline-block;padding: 5px 15px;border: 1px solid #15c;text-decoration: none;border-radius: 5px;font-size: 16px;">
                                Verify Email Address
                            </a>
                        </center>                                        
                    </td>
                </tr>  
                <tr>
                    <td height="20px">
                        
                    </td>
                </tr>        
                <tr>
                    <td style="padding: 0px 20px 0px 20px;">
                        <p>
                            <span style="color: black;font-size: 18px;">Regards</span>                            
                        </p>  
                    </td>
                </tr>   
                <tr>
                    <td height="20px">
                        
                    </td>
                </tr>         
            </tbody>
        </table>


    </center>
</body>

</html>
