@extends('layouts.company')

@section('content')

<section class="content mt-2">
    <div class="container-fluid">
    
        <div class="row">
            test
        </div>
        
    </div>   
</section>

@endsection
